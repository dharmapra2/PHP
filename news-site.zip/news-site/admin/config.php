<?php
$hostName= "https://localhost/news-site";
$conn=mysqli_connect("localhost:3307","root","","news-site") or die("Connection failed..". mysqli_connect_error());
?>