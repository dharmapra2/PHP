<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php
                    date_default_timezone_set("Asia/Kolkata");
                ?>
                <span>&copy;Copyright 2021-<?php echo date("y");?> News | Powered by <a href="https://github.com/dharmapra2">Dharma Pradhan</a></span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
